package com.reelkeep.app;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;

/** Local information sheet, visually paired with the B.2 playback rail. */
final class PlayerInfo extends LinearLayout {
    final WebView web;
    PlayerInfo(PlayerActivity activity, String id, Runnable close) {
        super(activity);
        setOrientation(VERTICAL);
        String language = activity.getSharedPreferences("preferences", 0).getString("language", "en");
        boolean dark = MainActivity.darkTheme(activity);
        int ink = dark ? 0xfff1f2f4 : 0xff16171a;
        GradientDrawable surface = new GradientDrawable();
        surface.setColor(dark ? 0xff16181b : 0xfff5f4f1);
        float radius = activity.dp(28);
        surface.setCornerRadii(new float[]{radius, radius, radius, radius, 0, 0, 0, 0});
        setBackground(surface); setClipToOutline(true); setElevation(activity.dp(6));

        FrameLayout handleArea = new FrameLayout(activity);
        View handle = new View(activity);
        GradientDrawable gripShape = new GradientDrawable();
        gripShape.setColor(dark ? 0xff76787c : 0xffa5a8ad);
        gripShape.setCornerRadius(activity.dp(3)); handle.setBackground(gripShape);
        handleArea.addView(handle, new FrameLayout.LayoutParams(activity.dp(32), activity.dp(4), Gravity.CENTER));
        addView(handleArea, new LinearLayout.LayoutParams(-1, activity.dp(22)));

        LinearLayout header = new LinearLayout(activity); header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(activity.dp(23), 0, activity.dp(10), 0);
        TextView label = activity.text(language.equals("ru") ? "О ВИДЕО" : "ABOUT VIDEO", 9,
                dark ? 0xff5d5f63 : 0xff6b6d71);
        label.setLetterSpacing(.12f); label.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        header.addView(label, new LinearLayout.LayoutParams(0, activity.dp(48), 1));
        PlayerGlyphButton more = new PlayerGlyphButton(activity, "more", "Дополнительные действия", activity.font);
        more.ink(ink); header.addView(more, new LinearLayout.LayoutParams(activity.dp(48), activity.dp(48)));
        more.setOnClickListener(v -> activity.options());
        PlayerGlyphButton done = new PlayerGlyphButton(activity, "down", "Свернуть информацию", activity.font);
        done.ink(ink); header.addView(done, new LinearLayout.LayoutParams(activity.dp(48), activity.dp(48)));
        done.setOnClickListener(v -> close.run());
        final float[] drag = new float[2];
        View.OnTouchListener dismiss = (v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                drag[0] = event.getRawY(); drag[1] = event.getRawX(); return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP &&
                    event.getRawY() - drag[0] > activity.dp(80) &&
                    Math.abs(event.getRawX() - drag[1]) < event.getRawY() - drag[0]) close.run();
            return true;
        };
        header.setOnTouchListener(dismiss); handleArea.setOnTouchListener(dismiss); addView(header);
        web = new WebView(activity); web.setBackgroundColor(dark ? 0xff16181b : 0xfff5f4f1);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setAllowFileAccess(false); web.getSettings().setAllowContentAccess(false);
        web.getSettings().setBlockNetworkLoads(true);
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public boolean copyRecipe(String text) {
                return RecipeClipboard.copy(activity, text);
            }
        }, "PlayerTools");
        final String selected = dark ? "graphite" : "light";
        web.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }
            public void onPageFinished(WebView v, String url) {
                try {
                    JSONObject item = Store.shared(activity).find(id);
                    v.evaluateJavascript("showInfo(" + item.toString() + "," + JSONObject.quote(language) + "," + JSONObject.quote(selected) + ")", null);
                } catch (Exception ignored) {}
            }
        });
        addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        web.loadUrl("file:///android_asset/player-info.html");
    }
    void dispose() { web.removeJavascriptInterface("PlayerTools"); web.destroy(); }
}
