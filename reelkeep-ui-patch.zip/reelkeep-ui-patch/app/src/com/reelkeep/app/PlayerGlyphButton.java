package com.reelkeep.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

/** A real button View: glyphs never depend on TextView's scrolling, tint or font. */
final class PlayerGlyphButton extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Typeface font;
    private String kind;
    private int ink = 0xfff1f2f4;

    PlayerGlyphButton(Context context, String kind, String label, Typeface font) {
        super(context);
        this.font = font;
        setClickable(true);
        setFocusable(true);
        setMinimumWidth(dp(48));
        setMinimumHeight(dp(48));
        setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),
                new ColorDrawable(Color.TRANSPARENT), null));
        icon(kind, label);
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    void ink(int color) { ink = color; invalidate(); }

    void icon(String next, String label) {
        boolean changed = !next.equals(kind);
        kind = next;
        String accessible = Lang.text(getContext(), label);
        if (!accessible.contentEquals(getContentDescription() == null ? "" : getContentDescription())) {
            setContentDescription(accessible);
            setTooltipText(accessible);
        }
        if (changed) invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float density = getResources().getDisplayMetrics().density;
        canvas.save();
        canvas.translate(getWidth() / 2f, getHeight() / 2f);
        canvas.scale(density, density);
        paint.reset();
        paint.setAntiAlias(true);
        if (kind.equals("pause") || kind.equals("play")) {
            paint.setShader(new android.graphics.LinearGradient(-12, -16, 12, 16,
                    0x35ffffff, 0x0affffff, android.graphics.Shader.TileMode.CLAMP));
            canvas.drawCircle(0, 0, 16, paint);
            paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(.6f);
            paint.setColor(0x35ffffff);
            canvas.drawArc(-15.7f, -15.7f, 15.7f, 15.7f, 205, 125, false, paint);
        }
        paint.setShader(null);
        paint.setColor(ink);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.7f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setShadowLayer(1.4f, 0, .7f, 0x80000000);
        path.reset();
        if (kind.equals("back")) {
            path.moveTo(3, -7); path.lineTo(-4, 0); path.lineTo(3, 7);
        } else if (kind.equals("down")) {
            path.moveTo(-5, -2.5f); path.lineTo(0, 2.5f); path.lineTo(5, -2.5f);
        } else if (kind.equals("more")) {
            paint.setStyle(Paint.Style.FILL);
            for (int x = -6; x <= 6; x += 6) canvas.drawCircle(x, 0, 1.3f, paint);
        } else if (kind.equals("pause")) {
            paint.setStrokeWidth(2.6f);
            canvas.drawLine(-3.5f, -5.5f, -3.5f, 5.5f, paint);
            canvas.drawLine(3.5f, -5.5f, 3.5f, 5.5f, paint);
        } else if (kind.equals("play")) {
            paint.setStyle(Paint.Style.FILL);
            path.moveTo(-3.5f, -6.5f); path.lineTo(6, 0); path.lineTo(-3.5f, 6.5f); path.close();
        } else if (kind.equals("rewind") || kind.equals("forward")) {
            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(font == null ? Typeface.create("sans-serif-medium", 0) : font);
            paint.setTextSize(10.5f);
            paint.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics metrics = paint.getFontMetrics();
            canvas.drawText(kind.equals("rewind") ? "−10" : "+10", 0,
                    -(metrics.ascent + metrics.descent) / 2, paint);
        } else {
            path.moveTo(-8, -3); path.lineTo(-4, -3); path.lineTo(1, -7);
            path.lineTo(1, 7); path.lineTo(-4, 3); path.lineTo(-8, 3); path.close();
            if (kind.equals("muted")) {
                canvas.drawLine(5, -3, 10, 3, paint);
                canvas.drawLine(10, -3, 5, 3, paint);
            } else {
                canvas.drawArc(-3, -7, 10, 7, -55, 110, false, paint);
            }
        }
        canvas.drawPath(path, paint);
        canvas.restore();
    }

    @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        info.setClassName("android.widget.Button");
    }
}
