package com.reelkeep.app;

import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.widget.LinearLayout;

/** Small backdrop samples only while the rail is visible. Works with VideoView's SurfaceView on API 26+. */
final class PlayerGlassRail extends LinearLayout {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF bounds = new RectF(), sampleBounds = new RectF();
    private final Path clip = new Path();
    private final Handler handler = new Handler();
    private SurfaceView source;
    private Bitmap sample;
    private boolean running, copying, disposed;
    private int generation;

    PlayerGlassRail(Context context) {
        super(context);
        setOrientation(HORIZONTAL);
        setGravity(android.view.Gravity.CENTER_VERTICAL);
        setWillNotDraw(false);
        setElevation(0);
    }

    void start(SurfaceView video) {
        source = video;
        if (running || disposed) return;
        running = true;
        handler.post(capture);
    }

    void stop() { running = false; generation++; handler.removeCallbacks(capture); }
    void dispose() { stop(); disposed = true; sample = null; source = null; }

    private final Runnable capture = new Runnable() {
        @Override public void run() {
            if (!running || disposed) return;
            handler.postDelayed(this, 180);
            if (copying || source == null || getWidth() <= 0 || getHeight() <= 0
                    || !source.getHolder().getSurface().isValid()) return;
            int[] rail = new int[2], video = new int[2];
            getLocationOnScreen(rail); source.getLocationOnScreen(video);
            Rect intersect = new Rect(rail[0], rail[1], rail[0] + getWidth(), rail[1] + getHeight());
            if (!intersect.intersect(video[0], video[1], video[0] + source.getWidth(), video[1] + source.getHeight())) {
                if (sample != null) { sample = null; invalidate(); }
                return;
            }
            Rect surface = source.getHolder().getSurfaceFrame();
            float sx = surface.width() / (float) Math.max(1, source.getWidth());
            float sy = surface.height() / (float) Math.max(1, source.getHeight());
            Rect rect = new Rect(Math.max(0, Math.round((intersect.left - video[0]) * sx)),
                    Math.max(0, Math.round((intersect.top - video[1]) * sy)),
                    Math.min(surface.width(), Math.round((intersect.right - video[0]) * sx)),
                    Math.min(surface.height(), Math.round((intersect.bottom - video[1]) * sy)));
            if (rect.width() <= 0 || rect.height() <= 0) return;
            float factor = 112f / Math.max(1, getWidth());
            Bitmap next = Bitmap.createBitmap(Math.max(1, Math.round(intersect.width() * factor)),
                    Math.max(1, Math.round(intersect.height() * factor)), Bitmap.Config.ARGB_8888);
            RectF destination = new RectF(intersect.left - rail[0], intersect.top - rail[1],
                    intersect.right - rail[0], intersect.bottom - rail[1]);
            final int token = generation;
            copying = true;
            try {
                PixelCopy.request(source, rect, next, result -> {
                    copying = false;
                    if (disposed || !running || token != generation) { next.recycle(); return; }
                    if (result == PixelCopy.SUCCESS) {
                        blur(next);
                        sample = next;
                        sampleBounds.set(destination);
                        invalidate();
                    } else next.recycle();
                }, handler);
            } catch (RuntimeException unavailable) { copying = false; next.recycle(); }
        }
    };

    private static void blur(Bitmap bitmap) {
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        int[] pixels = new int[w * h], temp = new int[w * h];
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
        // Tiny downsample + two separable box passes; no full-frame snapshots or shader dependency.
        final int radius = 3, size = radius * 2 + 1;
        for (int pass = 0; pass < 2; pass++) {
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0;
                for (int k = -radius; k <= radius; k++) {
                    int c = pixels[y * w + Math.max(0, Math.min(w - 1, x + k))];
                    r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255;
                }
                temp[y * w + x] = 0xff000000 | ((r / size) << 16) | ((g / size) << 8) | b / size;
            }
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0;
                for (int k = -radius; k <= radius; k++) {
                    int c = temp[Math.max(0, Math.min(h - 1, y + k)) * w + x];
                    r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255;
                }
                pixels[y * w + x] = 0xff000000 | ((r / size) << 16) | ((g / size) << 8) | b / size;
            }
        }
        bitmap.setPixels(pixels, 0, w, 0, 0, w, h);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float d = getResources().getDisplayMetrics().density, radius = getHeight() / 2f;
        bounds.set(.6f * d, .6f * d, getWidth() - .6f * d, getHeight() - .6f * d);
        clip.reset(); clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
        canvas.save(); canvas.clipPath(clip);
        paint.setStyle(Paint.Style.FILL); paint.setShader(null); paint.setColor(0xff0e0f11);
        canvas.drawRect(bounds, paint);
        if (sample != null) { paint.setAlpha(255); canvas.drawBitmap(sample, null, sampleBounds, paint); }
        paint.setShader(new LinearGradient(0, 0, getWidth() * .65f, getHeight(),
                0x8c1e2024, 0xb3101114, Shader.TileMode.CLAMP));
        canvas.drawRect(bounds, paint);
        paint.setShader(new LinearGradient(0, 0, 0, getHeight(), 0x1affffff, 0x02ffffff, Shader.TileMode.CLAMP));
        canvas.drawRect(bounds, paint);
        canvas.restore();
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(.8f * d);
        paint.setShader(new LinearGradient(0, 0, 0, getHeight(), 0x45ffffff, 0x14ffffff, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(bounds, radius, radius, paint);
        paint.setStrokeWidth(.7f * d);
        paint.setShader(new LinearGradient(20 * d, 0, getWidth() - 20 * d, 0,
                new int[]{0x00ffffff, 0x90ffffff, 0x20ffffff, 0x00ffffff},
                new float[]{0, .28f, .72f, 1}, Shader.TileMode.CLAMP));
        canvas.drawLine(radius, d, getWidth() - radius, d, paint);
        paint.setShader(null);
    }

    @Override protected void dispatchDraw(Canvas canvas) {
        int saved = canvas.save();
        canvas.clipPath(clip);
        super.dispatchDraw(canvas);
        canvas.restoreToCount(saved);
    }
}
