package com.reelkeep.app;
/** Distance is in dp, velocity in dp/sec. Only deliberate downward gestures dismiss. */
final class DismissSwipe{
 static boolean vertical(float dx,float dy){return dy>12&&dy>Math.abs(dx)*1.4f;}
 static boolean finish(float dx,float dy,float velocity,float height){return vertical(dx,dy)&&(dy>=Math.max(72,height*.14f)||dy>=48&&velocity>=850);}
}
