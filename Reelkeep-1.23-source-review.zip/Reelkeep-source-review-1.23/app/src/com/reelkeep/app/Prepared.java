package com.reelkeep.app;
import org.json.*;import java.net.*;
public final class Prepared {
 static final long MAX_AGE=30*60*1000L;
 static boolean usable(JSONObject item,long now){long timestamp=item.optLong("videoPreparedAt"),age=now-timestamp;if(timestamp<=0||age<0||age>=MAX_AGE)return false;try{return item.optString("downloadEngine").equals("yt-dlp")?PlatformLinks.external(item.optString("videoUrl")):WebMedia.allowed(new URL(item.optString("videoUrl")),true);}catch(Exception e){return false;}}
}
