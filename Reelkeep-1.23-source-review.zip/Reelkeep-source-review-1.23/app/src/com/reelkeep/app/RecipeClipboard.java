package com.reelkeep.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

/** Plain text only, invoked by the local, network-blocked information sheet. */
final class RecipeClipboard {
    static boolean copy(Context context, String text) {
        if (text == null || text.trim().isEmpty() || text.length() > 100000) return false;
        try {
            ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard == null) return false;
            clipboard.setPrimaryClip(ClipData.newPlainText("Reelkeep recipe", text));
            return true;
        } catch (RuntimeException failure) { return false; }
    }
}
