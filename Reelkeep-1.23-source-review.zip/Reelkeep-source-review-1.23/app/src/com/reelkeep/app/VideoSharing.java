package com.reelkeep.app;

import android.content.*;
import android.net.Uri;
import org.json.JSONObject;
import java.io.*;

/** Shares a single existing local video using a temporary read grant, without copying it. */
final class VideoSharing {
    static final String MIME = "video/mp4";
    static Uri uri(Context context, String id) {
        return new Uri.Builder().scheme("content").authority(context.getPackageName()+".videoshare")
                .appendPath(id).appendPath("video.mp4").build();
    }
    static String id(Context context, Uri uri) throws FileNotFoundException {
        if (!"content".equals(uri.getScheme()) || !(context.getPackageName()+".videoshare").equals(uri.getAuthority())
                || uri.getPathSegments().size()!=2 || !"video.mp4".equals(uri.getLastPathSegment())
                || !uri.getPathSegments().get(0).matches("[a-f0-9-]{36}") || uri.getQuery()!=null || uri.getFragment()!=null)
            throw new FileNotFoundException("Unknown video");
        return uri.getPathSegments().get(0);
    }
    static JSONObject item(Context context, Uri uri) throws FileNotFoundException {
        try { return Store.shared(context).find(id(context,uri)); }
        catch(Exception error) { throw new FileNotFoundException("Video unavailable"); }
    }
    static File file(Context context, Uri uri) throws FileNotFoundException {
        File file=MediaDepot.local(context,item(context,uri));
        if(file==null)throw new FileNotFoundException("Download the video first");
        return file;
    }
    static String filename(JSONObject item) {
        String name=item.optString("title","").replaceAll("[^\\p{L}\\p{N} _-]","").trim();
        if(name.length()>70)name=name.substring(0,70);
        return (name.isEmpty()?"Reelkeep-video":name)+".mp4";
    }
    static Intent intent(Context context,String id) throws IOException {
        Uri uri=uri(context,id);file(context,uri);
        Intent intent=new Intent(Intent.ACTION_SEND).setType(MIME).putExtra(Intent.EXTRA_STREAM,uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newRawUri("Reelkeep video",uri));return intent;
    }
}
