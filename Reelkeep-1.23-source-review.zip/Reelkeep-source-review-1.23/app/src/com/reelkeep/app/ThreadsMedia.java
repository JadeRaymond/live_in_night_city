package com.reelkeep.app;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

/** Public Threads page data. The requested post is selected before its attachment is followed. */
final class ThreadsMedia {
    static boolean host(URL url) {
        String h = url.getHost().toLowerCase(Locale.ROOT);
        return url.getProtocol().equals("https") && url.getUserInfo() == null && url.getPort() == -1 &&
                (h.equals("threads.com") || h.equals("www.threads.com") || h.equals("threads.net") || h.equals("www.threads.net"));
    }

    static String page(String input) throws Exception {
        URL url = new URL(input);
        for (int redirect = 0; redirect < 5; redirect++) {
            if (!host(url)) throw new IOException("unsupported_host");
            if (url.getPath().startsWith("/login") || url.getPath().startsWith("/accounts/"))
                throw new IOException("source_login_required");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(12000); connection.setReadTimeout(18000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8");
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            connection.setRequestProperty("Sec-Fetch-Dest", "document");
            connection.setRequestProperty("Sec-Fetch-Mode", "navigate");
            connection.setRequestProperty("Sec-Fetch-Site", "none");
            connection.setRequestProperty("Upgrade-Insecure-Requests", "1");
            // No Instagram account cookies or other session data are sent.
            try {
                int code = connection.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = connection.getHeaderField("Location");
                    if (location == null) throw new IOException("redirect_missing");
                    url = new URL(url, location); continue;
                }
                if (code == 401 || code == 403) throw new IOException("source_login_required");
                if (code == 404 || code == 410) throw new IOException("source_unavailable");
                if (code != 200) throw new IOException("http_" + code);
                try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] block = new byte[16384]; int n;
                    while ((n = in.read(block)) != -1) {
                        if (out.size() + n > 2500000) throw new IOException("response_too_large");
                        out.write(block, 0, n);
                    }
                    return out.toString("UTF-8");
                }
            } finally { connection.disconnect(); }
        }
        throw new IOException("too_many_redirects");
    }

    static JSONObject metadata(String url) throws Exception {
        JSONObject result = parse(page(url), url);
        // Occasionally a public page is sent without its media preloader. Try one locale variant,
        // but never replace a correctly matched text-only post with a recommended video.
        if (!result.optBoolean("threadsPostMatched")) {
            try {
                JSONObject retry = parse(page(url + "?hl=en"), url);
                if (retry.optBoolean("threadsPostMatched")) return retry;
            } catch (Exception ignored) {}
        }
        return result;
    }

    static JSONObject parse(String html, String input) throws Exception {
        String canonical = PlatformLinks.canonical(input);
        if (!PlatformLinks.source(canonical).equals("threads")) throw new IOException("unsupported_source");
        String code = canonical.substring(canonical.lastIndexOf('/') + 1);
        JSONObject post = null;
        Matcher scripts = Pattern.compile("<script\\b([^>]*)>(.*?)</script>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(html);
        while (scripts.find() && post == null) {
            if (!scripts.group(1).toLowerCase(Locale.ROOT).contains("application/json") || !scripts.group(2).contains(code)) continue;
            try { post = find(new JSONTokener(scripts.group(2)).nextValue(), code); }
            catch (JSONException ignored) {}
        }
        Map<String, String> meta = Smart.meta(html);
        String caption = post == null ? Smart.caption(meta) : caption(post);
        JSONObject media = post == null ? null : attachment(post, 0);
        String video = media == null ? "" : video(media);
        String image = media == null ? "" : image(media);
        if (image.isEmpty()) image = meta.containsKey("og:image") ? meta.get("og:image") : "";
        if (media != null && media != post) {
            String quoted = caption(media);
            if (!quoted.isEmpty() && !caption.contains(quoted)) caption = caption.isEmpty() ? quoted : caption + "\n\n" + quoted;
        }
        JSONObject result = Smart.analyze(caption);
        return result.put("source", "threads").put("sourceId", code).put("downloadEngine", "threads-public").put("imageUrl", image).put("threadsPostMatched", post != null)
                .put("videoUrl", video).put("status", !caption.isEmpty() ? "metadata" : !image.isEmpty() ? "cover_only" : "unavailable")
                .put("errorReason", video.isEmpty() ? "video_unavailable" : "");
    }

    private static JSONObject find(Object root, String code) throws JSONException {
        ArrayDeque<Object> queue = new ArrayDeque<>(); queue.add(root);
        for (int visited = 0; !queue.isEmpty() && visited < 100000; visited++) {
            Object node = queue.removeFirst();
            if (node instanceof JSONObject) {
                JSONObject o = (JSONObject) node;
                if ((code.equals(o.optString("code")) || code.equals(o.optString("shortcode"))) &&
                        (o.has("video_versions") || o.has("carousel_media") || o.has("text_post_app_info"))) return o;
                Iterator<String> keys = o.keys();
                while (keys.hasNext()) { Object value = o.get(keys.next()); if (value instanceof JSONObject || value instanceof JSONArray) queue.addLast(value); }
            } else if (node instanceof JSONArray) {
                JSONArray a = (JSONArray) node;
                for (int i = 0; i < a.length(); i++) { Object value = a.get(i); if (value instanceof JSONObject || value instanceof JSONArray) queue.addLast(value); }
            }
        }
        return null;
    }

    private static JSONObject attachment(JSONObject post, int depth) throws Exception {
        if (depth > 6) return null;
        if (!video(post).isEmpty()) return post;
        JSONArray album = post.optJSONArray("carousel_media");
        if (album != null) for (int i = 0; i < album.length(); i++) {
            JSONObject child = album.optJSONObject(i);
            JSONObject found = child == null ? null : attachment(child, depth + 1);
            if (found != null) return found;
        }
        JSONObject info = post.optJSONObject("text_post_app_info");
        JSONObject share = info == null ? null : info.optJSONObject("share_info");
        JSONObject quoted = share == null ? null : share.optJSONObject("quoted_attachment_post");
        return quoted == null ? null : attachment(quoted, depth + 1);
    }

    private static String caption(JSONObject post) {
        JSONObject caption = post.optJSONObject("caption");
        return caption == null ? "" : caption.optString("text").trim();
    }

    private static String video(JSONObject media) {
        JSONArray versions = media.optJSONArray("video_versions");
        if (versions != null) for (int i = 0; i < versions.length(); i++) {
            JSONObject version = versions.optJSONObject(i); String url = version == null ? "" : version.optString("url");
            try { if (WebMedia.allowed(new URL(url), true)) return url; } catch (Exception ignored) {}
        }
        return "";
    }

    private static String image(JSONObject media) {
        JSONObject images = media.optJSONObject("image_versions2");
        JSONArray versions = images == null ? null : images.optJSONArray("candidates");
        if (versions != null) for (int i = 0; i < versions.length(); i++) {
            JSONObject version = versions.optJSONObject(i); String url = version == null ? "" : version.optString("url");
            try { if (WebMedia.allowed(new URL(url), true)) return url; } catch (Exception ignored) {}
        }
        return "";
    }
}
