package com.reelkeep.app;
import android.content.*;import android.net.*;
final class NetworkGate{
 static boolean waiting(Context c){try{org.json.JSONArray items=new org.json.JSONObject(Store.shared(c).read()).getJSONArray("items");for(int i=0;i<items.length();i++)if(items.getJSONObject(i).optString("downloadStatus").equals("waiting_network"))return true;}catch(Exception ignored){}return false;}
 static void resumeWaiting(Context c){if(!allowed(c))return;try{org.json.JSONArray items=new org.json.JSONObject(Store.shared(c).read()).getJSONArray("items");for(int i=0;i<items.length();i++){org.json.JSONObject item=items.getJSONObject(i);if(item.optString("downloadStatus").equals("waiting_network"))MediaDepot.download(c,item.getString("id"),false);}}catch(Exception ignored){}}
 static boolean ready(Context c){ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);NetworkCapabilities cap=cm.getNetworkCapabilities(cm.getActiveNetwork());return cap!=null&&cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);}
 static boolean allowed(Context c){if(!ready(c))return false;if(!c.getSharedPreferences("preferences",0).getBoolean("wifiOnly",false))return true;ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);NetworkCapabilities cap=cm.getNetworkCapabilities(cm.getActiveNetwork());return cap!=null&&cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);}
}
