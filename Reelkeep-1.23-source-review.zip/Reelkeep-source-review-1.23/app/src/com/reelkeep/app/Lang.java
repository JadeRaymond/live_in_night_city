package com.reelkeep.app;
import android.content.Context;import org.json.*;import java.io.*;
final class Lang{
 static JSONObject english;
 static synchronized String text(Context c,String value){if(value==null)return "";if(!c.getSharedPreferences("preferences",0).getString("language","en").equals("en"))return value;try{if(english==null){InputStream in=c.getAssets().open("locales/en.json");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);in.close();english=new JSONObject(out.toString("UTF-8"));}return english.optString(value,value);}catch(Exception e){return value;}}
}
