package com.reelkeep.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Quiet Remote-inspired native material: shaded body, directional rim and soft glint. */
final class ControlSurface extends Drawable{
 final Paint body=new Paint(3),rim=new Paint(3),light=new Paint(3);final RectF shape=new RectF();final int top,bottom,edgeHigh,edgeLow,glint;final float radius,width;final SurfaceLighting lighting;float previousX=Float.NaN,previousY=Float.NaN;
 ControlSurface(SurfaceLighting lighting,int top,int bottom,int edgeHigh,int edgeLow,int glint,float radius,float width){this.lighting=lighting;this.top=top;this.bottom=bottom;this.edgeHigh=edgeHigh;this.edgeLow=edgeLow;this.glint=glint;this.radius=radius;this.width=width;rim.setStyle(Paint.Style.STROKE);rim.setStrokeWidth(width);lighting.add(this);}
 protected void onBoundsChange(Rect bounds){shape.set(bounds.left+width/2,bounds.top+width/2,bounds.right-width/2,bounds.bottom-width/2);body.setShader(new LinearGradient(0,shape.top,0,shape.bottom,top,bottom,Shader.TileMode.CLAMP));previousX=Float.NaN;}
 void illuminate(){if(shape.isEmpty())return;float x=lighting.x,y=lighting.y;if(x==previousX&&y==previousY)return;previousX=x;previousY=y;float dx=x*shape.width()/2,dy=y*shape.height()/2;rim.setShader(new LinearGradient(shape.centerX()+dx,shape.centerY()+dy,shape.centerX()-dx,shape.centerY()-dy,edgeHigh,edgeLow,Shader.TileMode.CLAMP));light.setShader(new RadialGradient(shape.centerX()+dx*.55f,shape.centerY()+dy*.55f,Math.max(shape.width(),shape.height())*.46f,(glint<<24)|0xffffff,0x00ffffff,Shader.TileMode.CLAMP));}
 public void draw(Canvas canvas){if(shape.isEmpty())return;illuminate();float corner=Math.min(radius,shape.height()/2);canvas.drawRoundRect(shape,corner,corner,body);canvas.drawRoundRect(shape,corner,corner,light);canvas.drawRoundRect(shape,corner,corner,rim);}
 public void getOutline(Outline outline){outline.setRoundRect(getBounds(),Math.min(radius,getBounds().height()/2f));outline.setAlpha(1);}
 public int getOpacity(){return PixelFormat.TRANSLUCENT;}public void setAlpha(int alpha){body.setAlpha(alpha);rim.setAlpha(alpha);light.setAlpha(alpha);invalidateSelf();}public void setColorFilter(ColorFilter filter){body.setColorFilter(filter);invalidateSelf();}
}
