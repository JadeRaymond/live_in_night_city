package com.reelkeep.app;
/** Shared bounds/eligibility rules for durable playback position. */
final class PlaybackState{
 static int clamp(long position,long duration){return (int)Math.max(0,Math.min(Math.min(duration,Integer.MAX_VALUE),position));}
 static int resumeAt(long position,long duration,boolean completed){if(completed||duration<=0)return 0;int p=clamp(position,duration);return p>=3000&&duration-p>Math.max(3000,duration/20)?p:0;}
}
