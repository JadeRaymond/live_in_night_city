package com.reelkeep.app;

import android.content.*;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;

/** Private provider with temporary read grants for exactly one installed APK. */
public final class ApkShareProvider extends ContentProvider {
    public boolean onCreate() { return true; }
    private File apk(Uri uri) throws FileNotFoundException {
        if (!ApkSharing.uri(getContext()).equals(uri)) throw new FileNotFoundException("Unknown file");
        try { return ApkSharing.installed(getContext()); }
        catch (IOException error) { throw new FileNotFoundException(error.getMessage()); }
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(apk(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }
    public String getType(Uri uri) {
        if (!ApkSharing.uri(getContext()).equals(uri)) throw new IllegalArgumentException("Unknown file");
        return ApkSharing.MIME;
    }
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        File file;
        try { file = apk(uri); } catch (IOException error) { return null; }
        String[] columns = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor result = new MatrixCursor(columns, 1);
        Object[] row = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) row[i] = ApkSharing.filename(getContext());
            else if (OpenableColumns.SIZE.equals(columns[i])) row[i] = file.length();
        }
        result.addRow(row); return result;
    }
    public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException("Read only"); }
    public int delete(Uri uri, String selection, String[] args) { throw new UnsupportedOperationException("Read only"); }
    public int update(Uri uri, ContentValues values, String selection, String[] args) { throw new UnsupportedOperationException("Read only"); }
}
