package com.reelkeep.app;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import java.io.File;
import java.io.IOException;

/** Shares only the installed, signed, monolithic APK; never a catalog/archive. */
final class ApkSharing {
    static final String MIME = "application/vnd.android.package-archive";
    static String filename(Context c) {
        String version = "";
        try { version = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; }
        catch (Exception ignored) {}
        return "Reelkeep" + (version == null || version.isEmpty() ? "" : "-" + version.replaceAll("[^0-9A-Za-z._-]", "")) + ".apk";
    }
    static File installed(Context c) throws IOException {
        ApplicationInfo app = c.getApplicationInfo();
        if (app.splitSourceDirs != null && app.splitSourceDirs.length != 0)
            throw new IOException("Установка состоит из нескольких APK. Поделиться этой сборкой нельзя.");
        File file = new File(app.sourceDir == null ? "" : app.sourceDir);
        if (!file.isFile() || file.length() == 0) throw new IOException("Установочный APK не найден");
        return file;
    }
    static Uri uri(Context c) {
        return new Uri.Builder().scheme("content").authority(c.getPackageName() + ".apkshare")
                .appendPath(filename(c)).build();
    }
    static Intent intent(Context c) throws IOException {
        installed(c);
        Uri uri = uri(c);
        Intent intent = new Intent(Intent.ACTION_SEND).setType(MIME)
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, filename(c))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newRawUri(filename(c), uri));
        return intent;
    }
}
