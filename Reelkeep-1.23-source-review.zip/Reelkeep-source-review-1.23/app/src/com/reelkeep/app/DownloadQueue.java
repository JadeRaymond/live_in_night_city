package com.reelkeep.app;
import java.util.*;import java.util.concurrent.*;
/** One shared job per reel; a separate lane keeps taps out of the background queue. */
public final class DownloadQueue {
 public interface Work{String run(Job job)throws Exception;}
 public static final class Job implements Runnable{public final String id;public final CompletableFuture<String> future=new CompletableFuture<>();public volatile long bytes,total;public volatile String stage="queued";volatile boolean started,cancelled;volatile Thread runner;final Work work;final DownloadQueue owner;Job(String id,Work work,DownloadQueue owner){this.id=id;this.work=work;this.owner=owner;}public void run(){started=true;runner=Thread.currentThread();try{if(cancelled)throw new CancellationException("download_cancelled");future.complete(work.run(this));}catch(Throwable e){future.completeExceptionally(e);}finally{runner=null;Thread.interrupted();owner.remove(this);}}}
 final ThreadPoolExecutor background=(ThreadPoolExecutor)Executors.newFixedThreadPool(1),interactive=(ThreadPoolExecutor)Executors.newFixedThreadPool(1);final Map<String,Job> jobs=new HashMap<>();
 public synchronized Job submit(String id,boolean urgent,Work work){Job old=jobs.get(id);if(old!=null&&!old.future.isDone()){if(urgent&&!old.started&&background.getQueue().remove(old))interactive.execute(old);return old;}Job job=new Job(id,work,this);jobs.put(id,job);(urgent?interactive:background).execute(job);return job;}
 synchronized void remove(Job job){if(jobs.get(job.id)==job)jobs.remove(job.id);}
 public synchronized Job find(String id){return jobs.get(id);}public synchronized List<Job> snapshot(){return new ArrayList<>(jobs.values());}
 public synchronized void cancel(String id){Job job=jobs.get(id);if(job==null)return;job.cancelled=true;job.stage="cancelling";if(!job.started&&(background.getQueue().remove(job)||interactive.getQueue().remove(job))){job.future.completeExceptionally(new CancellationException("download_cancelled"));remove(job);}else if(job.runner!=null)job.runner.interrupt();}
 public void shutdown(){background.shutdownNow();interactive.shutdownNow();}
}
