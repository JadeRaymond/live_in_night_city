package com.reelkeep.app;
import android.content.Context;import android.hardware.*;import android.animation.ValueAnimator;import java.util.*;
/** Tilt light updates only registered material backgrounds, never the video surface. */
final class SurfaceLighting implements SensorEventListener{
 float x=-.35f,y=-.94f,smoothedX,smoothedZ;long lastUpdate;boolean started;final SensorManager manager;final Sensor sensor;final List<ControlSurface> surfaces=new ArrayList<>();
 SurfaceLighting(Context c){manager=(SensorManager)c.getSystemService(Context.SENSOR_SERVICE);Sensor available=manager==null?null:manager.getDefaultSensor(Sensor.TYPE_GRAVITY);sensor=available!=null?available:manager==null?null:manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);}
 void add(ControlSurface surface){surfaces.add(surface);}void start(){if(started||sensor==null||!ValueAnimator.areAnimatorsEnabled())return;started=manager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_UI);}void stop(){if(started)manager.unregisterListener(this);started=false;}
 public void onAccuracyChanged(Sensor s,int accuracy){}
 public void onSensorChanged(SensorEvent event){smoothedX+=(clamp(event.values[0]/9.81f)-smoothedX)*.15f;smoothedZ+=(clamp(event.values[2]/9.81f)-smoothedZ)*.15f;long now=android.os.SystemClock.elapsedRealtime();if(now-lastUpdate<70)return;lastUpdate=now;float a=-.35f+smoothedX*.7f,b=-.94f+(smoothedZ-.5f)*.45f;float length=Math.max(.001f,(float)Math.hypot(a,b));a/=length;b/=length;if(Math.abs(a-x)<.015f&&Math.abs(b-y)<.015f)return;x=a;y=b;for(ControlSurface surface:surfaces)surface.invalidateSelf();}
 static float clamp(float value){return Math.max(-1,Math.min(1,value));}
}
