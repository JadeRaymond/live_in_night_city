package com.reelkeep.app;

import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;

/** Only saved catalog videos; no arbitrary paths, private metadata or write access. */
public final class VideoShareProvider extends ContentProvider {
    public boolean onCreate(){return true;}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {
        if(!"r".equals(mode))throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(VideoSharing.file(getContext(),uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    public String getType(Uri uri){try{VideoSharing.id(getContext(),uri);return VideoSharing.MIME;}catch(IOException e){throw new IllegalArgumentException("Unknown video");}}
    public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){
        try{
            File file=VideoSharing.file(getContext(),uri);
            String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor cursor=new MatrixCursor(columns,1);Object[] row=new Object[columns.length];
            for(int i=0;i<columns.length;i++){
                if(OpenableColumns.DISPLAY_NAME.equals(columns[i]))row[i]=VideoSharing.filename(VideoSharing.item(getContext(),uri));
                else if(OpenableColumns.SIZE.equals(columns[i]))row[i]=file.length();
            }
            cursor.addRow(row);return cursor;
        }catch(IOException e){return null;}
    }
    public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read only");}
    public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
    public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
}
