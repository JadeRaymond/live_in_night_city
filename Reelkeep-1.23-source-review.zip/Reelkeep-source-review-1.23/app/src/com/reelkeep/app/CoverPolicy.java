package com.reelkeep.app;
import org.json.*;
public final class CoverPolicy {
 static String source(JSONObject item){if(item.optBoolean("thumbManual"))return "manual";String source=item.optString("thumbSource");return source.equals("instagram")||source.equals("frame")||source.equals("manual")?source:"unknown";}
 static boolean mayWrite(JSONObject item,boolean exists,String incoming){if(!incoming.equals("manual")&&!incoming.equals("instagram")&&!incoming.equals("frame"))return false;if(incoming.equals("manual"))return true;if(!exists)return true;if(source(item).equals("manual"))return false;return incoming.equals("instagram");}
}
