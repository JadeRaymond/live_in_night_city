#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
BT="$PWD/tools/android-15"
ANDROID="$PWD/tools/android-35/android.jar"
chmod +x "$BT/aapt2" "$BT/zipalign" "$BT/apksigner"
mkdir -p build/classes build/dex
"$BT/aapt2" compile --dir app/res -o build/resources.zip
"$BT/aapt2" link -o build/base.apk --manifest app/AndroidManifest.xml -I "$ANDROID" --java build/generated build/resources.zip -A app/assets
java -jar tools/ecj.jar -8 -proc:none -cp "$ANDROID:tools/ort.jar:tools/tess.jar" -d build/classes app/src/com/reelkeep/app/*.java build/generated/com/reelkeep/app/R.java
java -cp "$BT/lib/d8.jar" com.android.tools.r8.D8 --min-api 26 --lib "$ANDROID" --output build/dex tools/ort.jar tools/tess.jar $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes*.dex)
(cd build/native && zip -qr ../unsigned.apk lib)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
# Signing material is deliberately external to this review archive.
: "${REELKEEP_KEYSTORE:?Set the path to an external keystore}"
: "${REELKEEP_KS_PASS:?Set the keystore password in the environment}"
"$BT/apksigner" sign --ks "$REELKEEP_KEYSTORE" --ks-pass env:REELKEEP_KS_PASS --out build/reelkeep.apk build/aligned.apk
"$BT/apksigner" verify build/reelkeep.apk
"$BT/aapt2" dump badging build/reelkeep.apk | sed -n '1,12p'
